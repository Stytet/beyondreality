
execute as @a if entity @s[nbt={ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:rpm_multiplier modifier add 1-33-33-22-123 speed_buff 2 multiply_base
execute as @a if entity @s[nbt={ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:reload_speed modifier add 1-33-33-22-123 speed_buff 2 multiply_base
execute as @a if entity @s[nbt={ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:bolt_action_speed modifier add 1-33-33-22-123 speed_buff 2 multiply_base
execute as @a if entity @s[nbt={ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:draw_speed modifier add 1-33-33-22-123 speed_buff 2 multiply_base
execute as @a if entity @s[nbt=!{ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:rpm_multiplier modifier remove 1-33-33-22-123
execute as @a if entity @s[nbt=!{ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:reload_speed modifier remove 1-33-33-22-123
execute as @a if entity @s[nbt=!{ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:bolt_action_speed modifier remove 1-33-33-22-123
execute as @a if entity @s[nbt=!{ActiveEffects:[{Id:3}]}] run attribute @s tacz_attributes:draw_speed modifier remove 1-33-33-22-123



execute as @a if entity @s[nbt={ActiveEffects:[{Id:26}]}] run attribute @s tacz_attributes:hip_fire_accuracy modifier add 1-33-33-22-123 acc_buff 2 multiply_base
execute as @a if entity @s[nbt={ActiveEffects:[{Id:26}]}] run attribute @s tacz_attributes:ads_accuracy modifier add 1-33-33-22-123 acc_buff 2 multiply_base
execute as @a if entity @s[nbt=!{ActiveEffects:[{Id:26}]}] run attribute @s tacz_attributes:hip_fire_accuracy modifier remove 1-33-33-22-123
execute as @a if entity @s[nbt=!{ActiveEffects:[{Id:26}]}] run attribute @s tacz_attributes:ads_accuracy modifier remove 1-33-33-22-123
